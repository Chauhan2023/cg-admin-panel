import React, { useEffect, useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Container, Spinner, Card } from 'react-bootstrap';
import { apiGet } from '../../Api/apiMethods';

/* ─────────────────────────────────────────────────────────
   Sanitize image URL (strip stray backticks / quotes)
───────────────────────────────────────────────────────── */
const sanitizeUrl = (u) => {
    if (!u) return null;
    let s = String(u).trim().replace(/`/g, '');
    if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
        s = s.slice(1, -1).trim();
    }
    return s || null;
};

/* ─────────────────────────────────────────────────────────
   Read-only product slot — no dragging, no editing
───────────────────────────────────────────────────────── */
function SlotView({ product, pos }) {
    const rotation = product.rotation || 0;

    return (
        <div
            className="position-absolute"
            style={{ left: pos.x, top: pos.y, width: pos.width, height: pos.height }}
        >
            <div className="position-relative w-100 h-100 d-flex align-items-center justify-content-center">
                {/* Slot/background image */}
                {product.slotImage && (
                    <div
                        className="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center overflow-hidden"
                        style={{
                            transform: `rotate(${rotation}deg)`,
                            transformOrigin: 'center center',
                        }}
                    >
                        <img
                            src={product.slotImage}
                            alt=""
                            draggable={false}
                            style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                        />
                    </div>
                )}

                {/* Product image */}
                {product.productImage && (
                    <img
                        src={product.productImage}
                        alt={product.productActualName || 'Product'}
                        draggable={false}
                        style={{
                            maxWidth: '100%',
                            maxHeight: '100%',
                            objectFit: 'contain',
                            transform: `rotate(${rotation}deg)`,
                            position: 'relative',
                            zIndex: 1,
                        }}
                    />
                )}

                {/* Logo overlay (read-only, positioned absolutely) */}
                {product.logoImage && (
                    <img
                        src={product.logoImage}
                        alt="Logo"
                        draggable={false}
                        style={{
                            position: 'absolute',
                            left: pos.scaledLogoX,
                            top: pos.scaledLogoY,
                            width: pos.scaledLogoW,
                            height: pos.scaledLogoH,
                            objectFit: 'contain',
                            zIndex: 2,
                            transform: `rotate(${product.logoRotation || 0}deg)`,
                        }}
                    />
                )}
            </div>
        </div>
    );
}

/* ─────────────────────────────────────────────────────────
   Main read-only kit preview using Bootstrap
───────────────────────────────────────────────────────── */
function OrderKitPreview({ preview_id }) {
    const [viewportWidth, setViewportWidth] = useState(window.innerWidth);

    /* Track viewport width for scaling */
    useEffect(() => {
        const onResize = () => setViewportWidth(window.innerWidth);
        window.addEventListener('resize', onResize);
        return () => window.removeEventListener('resize', onResize);
    }, []);

    /* Fetch order data */
    const { data: orderData, isLoading } = useQuery({
        queryKey: ['OrderKitPreview', preview_id],
        queryFn: () => apiGet(`/getOrderById/${preview_id}`),
        enabled: !!preview_id,
        select: (res) => res?.data,
        retry: 2,
        retryDelay: 1000,
    });

    /* ── Parse the products array ── */
    const parsedKits = useMemo(() => {
        const products = orderData?.products;
        if (!Array.isArray(products) || products.length === 0) return null;

        return products
            .map((productGroup) => {
                const { mainBox, items } = productGroup || {};
                if (!mainBox || !Array.isArray(items)) return null;

                const rawW = Number(mainBox.width) || 0;
                const rawH = Number(mainBox.height) || 0;
                if (!rawW || !rawH) return null;

                // Restrict maximum scale of canvas based on viewport constraints
                const scale = rawW > 0 ? Math.min((viewportWidth * 0.88) / rawW, 1) : 1;
                const s = (v) => (Number(v) || 0) * scale;

                const canvasW = rawW * scale;
                const canvasH = rawH * scale;
                const dyeImage = sanitizeUrl(mainBox.dyeImage);

                const slots = items.map((item) => ({
                    categoryId:        item.categoryId,
                    productActualName: item.productActualName ?? null,
                    productImage:      sanitizeUrl(item.product?.image),
                    slotImage:         sanitizeUrl(item.slotImage),
                    logoImage:         sanitizeUrl(item.logo?.image),
                    rotation:          item.slot?.rotation || 0,
                    logoRotation:      item.logo?.rotation || 0,
                    pos: {
                        x:           s(item.slot?.x      || 0),
                        y:           s(item.slot?.y      || 0),
                        width:       s(item.slot?.width   || 0),
                        height:      s(item.slot?.height  || 0),
                        scaledLogoX: s(item.logo?.x       || 0),
                        scaledLogoY: s(item.logo?.y       || 0),
                        scaledLogoW: s(item.logo?.width    || 0),
                        scaledLogoH: s(item.logo?.height   || 0),
                    },
                }));

                return { canvasW, canvasH, dyeImage, slots, kitId: mainBox.kitId, price: mainBox.price };
            })
            .filter(Boolean);
    }, [orderData, viewportWidth]);

    if (isLoading) {
        return (
            <div className="d-flex justify-content-center my-4">
                <Spinner animation="border" variant="primary" />
            </div>
        );
    }
    
    if (!parsedKits || parsedKits.length === 0) {
        return (
            <div className="d-flex justify-content-center p-4 text-muted small">
                No kit preview available.
            </div>
        );
    }

    return (
        <div className="d-flex flex-column gap-4 w-100">
            {parsedKits.map((kit, index) => (
                <div key={kit.kitId || index} className="d-flex justify-content-center w-100 overflow-auto py-3">
                    {/* Main kit box canvas — read-only using Bootstrap styling */}
                    <div
                        className="position-relative shadow-sm border border-secondary rounded"
                        style={{
                            width:  kit.canvasW,
                            height: kit.canvasH,
                            backgroundImage:    kit.dyeImage ? `url(${kit.dyeImage})` : 'none',
                            backgroundSize:     'cover',
                            backgroundRepeat:   'no-repeat',
                            backgroundPosition: 'center',
                            flexShrink: 0
                        }}
                    >
                        {kit.slots.map((item) => (
                            <SlotView
                                key={item.categoryId || Math.random()}
                                product={item}
                                pos={item.pos}
                            />
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
}

export default OrderKitPreview;